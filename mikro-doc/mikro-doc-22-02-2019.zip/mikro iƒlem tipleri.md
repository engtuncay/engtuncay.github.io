

chaislemid	evraktip |	cinsi	| cha_tip|	cha_normal_Iade|	aciklama|	aciklamaek

1	1	0	1	0	Nakit Tahsilat	

2	34	0	1	0	Havale (Alacak)	

3	35	0	0	0	Havale Ödeme (Borç)(Gönderilen)	

4	4	1	1	0	Çek Alınan (Müşteri Çek Giriş)	

5	5	1	0	0	Portföydeki Çek Nakit (Borç)	

6	11	1	0	0	Takas Çek Çıkış (Borç)	

7	14	1	1	0	Takas Çek Ödeme (Alacak)	

8	67	3	0	0	Çek Verilen(Borç) (Firma Çek Çıkış)	

9	31	5	0	0	BD Borç Dekontu	Borç Dekontu olarak geçiyor Mikro Dökümanda 

10	32	5	1	0	BD Alacak Dekontu	

11	33	5	0	0	Genel Amaçlı Virman Dekontu(Borç)	Virman Dekontu olarak geçiyor Mikro 
Dökümanında

12	33	5	1	0	Genel Amaçlı Virman Dekontu(Alacak)	

13	57	5	0	0	Cari Hesaplar Arası Virman (Borç)	Müşteri Satıcı olarak geçiyor Mikro Dökümanda 

14	57	5	1	0	Cari Hesaplar Arası Virman (Alacak)	

15	110	5	0	0	Kasalar Arası Virman(Borç)	

16	110	5	1	0	Kasalar Arasi Virman(Alacak)	

17	0	6	1	0	Alış Faturası	

18	63	6	0	0	Satış Faturasi	

19	0	8	1	0	Alınan Hizmet Faturası	
20	63	8	0	0	Verilen Hizmet Faturası	
21	29	16	0	0	Açılış (Borç)	
22	29	16	1	0	Açılış (Alacak)	
23	1	19	1	0	Kredi Kartı Tahsilatı (Müşteri)	
24	54	19	0	0	Müşteri Kredi Kartı Ödeme(Borç)	
25	104	19	0	0	Bankalar Arası Kredi Kartı Transferi(Borç)	
26	64	22	0	0	Kredi Kartı Ödeme(Firma)(Borç)Tediye Makbuzu	
27	55	27	1	0	Gider Makbuzu(Alacak)	
28	37	0	1	0	Kasa Masraf Fişi (Alacak)	
29	0	6	1	1	İade (Bozuk ve Saglam) Faturası	
30	63	6	0	1	Satıcıya İade Faturası	


function unique(arr) {
  return Array.from(new Set(arr));
}

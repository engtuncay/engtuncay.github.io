# Advanced working with functions

importance: 5

---

# Output every second

Write a function `printNumbers(from, to)` that outputs a number every second, starting from `from` and ending with `to`.

Make two variants of the solution.

1. Using `setInterval`.
2. Using nested `setTimeout`.

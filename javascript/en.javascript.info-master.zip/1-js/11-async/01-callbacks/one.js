function one() {
  alert(1);
}

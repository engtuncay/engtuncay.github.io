# Object properties configuration

In this section we return to objects and study their properties even more in-depth.

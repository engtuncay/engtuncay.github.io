# JavaScript Fundamentals

Let's learn the fundamentals of script building.
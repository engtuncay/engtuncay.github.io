importance: 5

---

# The postfix and prefix forms

What are the final values of all variables `a`, `b`, `c` and `d` after the code below?

```js
let a = 1, b = 1;

let c = ++a; // ?
let d = b++; // ?
```

JavaScript-code:

```js demo run
let name = prompt("What is your name?", "");
alert(name);
```

The full page:

```html
<!DOCTYPE html>
<html>
<body>

  <script>
    'use strict';

    let name = prompt("What is your name?", "");
    alert(name);
  </script>

</body>
</html>
```

importance: 2

---

# The name of JavaScript

Using the `if..else` construct, write the code which asks: 'What is the "official" name of JavaScript?'

If the visitor enters "ECMAScript", then output "Right!", otherwise -- output: "You don't know? ECMAScript!"

![](ifelse_task2.svg)

[demo src="ifelse_task2"]

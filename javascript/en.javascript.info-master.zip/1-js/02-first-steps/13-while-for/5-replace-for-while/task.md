importance: 5

---

# Replace "for" with "while"

Rewrite the code changing the `for` loop to `while` without altering its behavior (the output should stay same).

```js run
for (let i = 0; i < 3; i++) {
  alert( `number ${i}!` );
}
```


importance: 3

---

# What's the result of OR'ed alerts?

What will the code below output?

```js
alert( alert(1) || 2 || alert(3) );
```


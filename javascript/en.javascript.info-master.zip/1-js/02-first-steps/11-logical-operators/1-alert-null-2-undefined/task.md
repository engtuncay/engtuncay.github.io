importance: 5

---

# What's the result of OR?

What is the code below going to output?

```js
alert( null || 2 || undefined );
```

